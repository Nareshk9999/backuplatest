import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-userManage',
 templateUrl: './user-manage.component.html', 
  styles: []
})
export class UserManageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
