import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-add-privilage',
  templateUrl: './add-privilage.component.html',
  styleUrls: ['./add-privilage.component.css']
})
export class AddPrivilageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
