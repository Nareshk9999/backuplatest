import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-add-resource',
  templateUrl: './add-resource.component.html',
  styleUrls: ['./add-resource.component.css']
})
export class AddResourceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
