import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-add-security',
  templateUrl: './add-security.component.html',
  styleUrls: ['./add-security.component.css']
})
export class AddSecurityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
